import math
import datetime
from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

# System state tracking live telemetry and emergency status
system_state = {
    "status": "NORMAL",  # NORMAL or EMERGENCY
    "telemetry": {
        "current_lat": None,
        "current_lng": None,
        "speed": 0.0,
        "distance": 0.0,
        "eta": 0.0,
        "bpm": 78,
        "spo2": 98
    },
    "destination": {
        "address": "",
        "lat": None,
        "lng": None
    },
    "v2x": {
        "message": "System Idle",
        "notified_vehicles": 0
    },
    "audit_logs": []
}

def add_log(event):
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    system_state["audit_logs"].insert(0, f"[{timestamp}] {event}")
    if len(system_state["audit_logs"]) > 20:
        system_state["audit_logs"].pop()

add_log("AI GreenCorridor Engine initialized with Live Hardware GPS.")

def calculate_haversine(lat1, lon1, lat2, lon2):
    """Calculates straight-line distance in kilometers between two coordinates."""
    if None in (lat1, lon1, lat2, lon2):
        return 0.0
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 + 
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 2)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/update-telemetry', methods=['POST'])
def update_telemetry():
    """Receives hardware GPS coordinates from browser sensor."""
    data = request.get_json() or {}
    lat = data.get("lat")
    lng = data.get("lng")
    speed_ms = data.get("speed", 0.0)

    if lat is not None and lng is not None:
        system_state["telemetry"]["current_lat"] = lat
        system_state["telemetry"]["current_lng"] = lng

    # Convert m/s to km/h
    speed_kmh = round((speed_ms or 0.0) * 3.6, 1)
    system_state["telemetry"]["speed"] = speed_kmh

    # Calculate remaining distance to custom hospital if set
    dest_lat = system_state["destination"]["lat"]
    dest_lng = system_state["destination"]["lng"]

    if lat and lng and dest_lat and dest_lng:
        dist = calculate_haversine(lat, lng, dest_lat, dest_lng)
        system_state["telemetry"]["distance"] = dist

        # Calculate ETA based on speed or default emergency velocity
        effective_speed = speed_kmh if speed_kmh > 0 else 45.0
        if system_state["status"] == "EMERGENCY":
            effective_speed *= 1.20  # Emergency priority factor

        system_state["telemetry"]["eta"] = round((dist / effective_speed) * 60, 1)

    return jsonify({
        "status": system_state["status"],
        "telemetry": system_state["telemetry"],
        "v2x": system_state["v2x"],
        "audit_logs": system_state["audit_logs"]
    })

@app.route('/set-custom-destination', methods=['POST'])
def set_custom_destination():
    """Sets user-entered destination hospital manually."""
    data = request.get_json() or {}
    address = data.get("address", "")
    lat = data.get("lat")
    lng = data.get("lng")

    if lat and lng:
        system_state["destination"]["address"] = address
        system_state["destination"]["lat"] = lat
        system_state["destination"]["lng"] = lng
        add_log(f"Destination updated to: {address}")
        return jsonify({"status": "success", "destination": system_state["destination"]})

    return jsonify({"status": "error", "message": "Invalid coordinates"}), 400

@app.route('/trigger-emergency', methods=['POST'])
def trigger_emergency():
    """Activates emergency mode and V2X broadcast system."""
    system_state["status"] = "EMERGENCY"
    system_state["v2x"]["message"] = "CLEAR THE LANE: Emergency Ambulance Approaching!"
    system_state["v2x"]["notified_vehicles"] = 42
    system_state["telemetry"]["bpm"] = 108
    system_state["telemetry"]["spo2"] = 93

    add_log("Emergency mode activated. Dynamic Green Corridor initiated. V2X Broadcast Sent.")
    return jsonify({"status": "EMERGENCY", "v2x": system_state["v2x"]})

@app.route('/reset-emergency', methods=['POST'])
def reset_emergency():
    """Resets system to normal operation."""
    system_state["status"] = "NORMAL"
    system_state["v2x"]["message"] = "System Idle"
    system_state["v2x"]["notified_vehicles"] = 0
    system_state["telemetry"]["bpm"] = 78
    system_state["telemetry"]["spo2"] = 98

    add_log("Emergency reset. Signals returned to standard traffic schedules.")
    return jsonify({"status": "NORMAL", "v2x": system_state["v2x"]})

if __name__ == '__main__':
    app.run(debug=True, port=5000)